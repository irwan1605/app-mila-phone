// ================================
// FirebaseService.js FINAL
// Lengkap untuk Mode 3 + Dashboard
// ================================

import {
  getDatabase,
  ref,
  set,
  push,
  update,
  remove,
  onValue,
  get,
} from "firebase/database";

import { db } from "./FirebaseInit";  // db sudah di-init di FirebaseInit.js

// ===============================
// USER MANAGEMENT (Realtime)
// ===============================
export const saveUserOnline = (user) =>
  set(ref(db, "users/" + user.username), user);

export const deleteUserOnline = (username) =>
  remove(ref(db, "users/" + username));

export const listenUsers = (callback) => {
  const r = ref(db, "users");
  return onValue(r, (snap) => {
    const v = snap.val() || {};
    callback(Object.values(v));
  });
};

export const getAllUsersOnce = async () => {
  const snap = await get(ref(db, "users"));
  const v = snap.val() || {};
  return Object.values(v);
};

// ===============================
// MASTER TOKO & DASHBOARD
// ===============================

// Ambil nama toko
export const getTokoName = async (tokoId) => {
  const snap = await get(ref(db, `toko/${tokoId}/info/name`));
  return snap.exists() ? snap.val() : `TOKO ${tokoId}`;
};

// Listen semua transaksi (Dashboard Pusat)
export const listenAllTransaksi = (callback) => {
  const r = ref(db, "toko");
  return onValue(r, (snap) => {
    const raw = snap.val() || {};
    const merged = [];

    Object.entries(raw).forEach(([tokoId, tokoData]) => {
      const tokoName = tokoData.info?.name || `TOKO ${tokoId}`;
      if (!tokoData.transaksi) return;

      Object.entries(tokoData.transaksi).forEach(([id, row]) => {
        merged.push({
          id,
          tokoId,
          TOKO: tokoName,
          TANGGAL: row.TANGGAL || "",
          BRAND: row.BRAND || "",
          WARNA: row.WARNA || "",
          QTY: row.QTY ?? 0,
          BATERAI: row.BATERAI || "",
          CHARGER: row.CHARGER || "",
          NAMA_SALES: row.NAMA_SALES || "",
          STATUS: row.STATUS || "Pending",
        });
      });
    });

    merged.sort((a, b) => new Date(b.TANGGAL) - new Date(a.TANGGAL));
    callback(merged);
  });
};

// Listen transaksi per toko
export const listenTransaksiByToko = (tokoId, callback) => {
  const r = ref(db, `toko/${tokoId}/transaksi`);
  return onValue(r, (snap) => {
    const raw = snap.val() || {};
    const list = Object.entries(raw).map(([id, data]) => ({ id, ...data }));
    callback(list);
  });
};

// Tambah transaksi toko
export const addTransaksi = (tokoId, data) => {
  const r = push(ref(db, `toko/${tokoId}/transaksi`));
  return set(r, data);
};

// Update transaksi
export const updateTransaksi = (tokoId, id, data) =>
  update(ref(db, `toko/${tokoId}/transaksi/${id}`), data);

// Hapus transaksi
export const deleteTransaksi = (tokoId, id) =>
  remove(ref(db, `toko/${tokoId}/transaksi/${id}`));


// =====================================================
// MODE 3 — PENJUALAN REALTIME (Dipakai DataManagement)
// =====================================================

// Tambah Penjualan
export const addPenjualan = (data) => {
  const r = push(ref(db, "penjualan"));
  return set(r, data);
};

// Update penjualan
export const updatePenjualan = (id, data) =>
  update(ref(db, "penjualan/" + id), data);

// Hapus penjualan
export const deletePenjualan = (id) =>
  remove(ref(db, "penjualan/" + id));

// Ambil penjualan realtime
export const listenPenjualan = (callback) => {
  const r = ref(db, "penjualan");
  return onValue(r, (snap) => {
    const raw = snap.val() || {};
    const list = Object.entries(raw).map(([id, v]) => ({ id, ...v }));
    callback(list);
  });
};

// Ambil penjualan sekali
export const getAllPenjualanOnce = async () => {
  const snap = await get(ref(db, "penjualan"));
  const raw = snap.val() || {};
  return Object.entries(raw).map(([id, v]) => ({ id, ...v }));
};
