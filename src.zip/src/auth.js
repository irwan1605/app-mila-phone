// src/auth.js
export const users = [
    { username: "superadmin", password: "admin123", role: "superadmin" },
  
    { username: "pic_toko1", password: "toko1pass", role: "toko1" },
    { username: "pic_toko2", password: "toko2pass", role: "toko2" },
    { username: "pic_toko3", password: "toko3pass", role: "toko3" },
    { username: "pic_toko4", password: "toko4pass", role: "toko4" },
    { username: "pic_toko5", password: "toko5pass", role: "toko5" },
    { username: "pic_toko6", password: "toko6pass", role: "toko6" },
    { username: "pic_toko7", password: "toko7pass", role: "toko7" },
    { username: "pic_toko8", password: "toko8pass", role: "toko8" },
    { username: "pic_toko9", password: "toko9pass", role: "toko9" },
    { username: "pic_toko10", password: "toko10pass", role: "toko10" },
  ];
  