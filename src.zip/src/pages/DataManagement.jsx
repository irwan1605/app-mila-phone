// src/pages/DataManagement.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

import {
  PAYMENT_METHODS,
  PRICE_CATEGORIES,
  MP_PROTECT_OPTIONS,
  TENOR_OPTIONS,
  BRAND_LIST,
  PRODUCT_LIST,
  WARNA_LIST,
} from "../data/ListDataPenjualan";
import { HARGA_PENJUALAN } from "../data/MasterDataHargaPenjualan";
import TOKO_LABELS_DEFAULT from "../data/TokoLabels";

// --- FIREBASE integration (Mode 3 = only penjualan realtime) ---
import {
  listenPenjualan,
  addPenjualan,
  updatePenjualan,
  deletePenjualan,
  getAllPenjualanOnce,
} from "../services/FirebaseService";

const FIREBASE_MODE = 3; // Mode 3 = only penjualan realtime
const USE_FIREBASE_PENJUALAN = FIREBASE_MODE === 3;

/* ===== Storage Keys ===== */
const STORAGE_MASTER_PRICE = "dm_master_harga";
const STORAGE_REF_LISTS = "dm_ref_lists";
const STORAGE_PENJUALAN = "dm_penjualan";

/* global LS keys used elsewhere (keamanan backward compatibility) */
const LS_MASTER_HARGA_PENJUALAN = "MASTER_HARGA_PENJUALAN";
const LS_MASTER_CATALOG_INDEX = "MASTER_CATALOG_INDEX";
const LS_MASTER_SALES_BY_TOKO = "MASTER_SALES_BY_TOKO";
const LS_MASTER_MDR_RULES = "MASTER_MDR_RULES";
const LS_MASTER_TENOR_RULES = "MASTER_TENOR_RULES";
const LS_MASTER_TOKO_LABELS = "MASTER_TOKO_LABELS";
const LS_MASTER_MP_PROTECT_OPTIONS = "MASTER_MP_PROTECT_OPTIONS";
const LS_MASTER_PAYMENT_METHODS = "MASTER_PAYMENT_METHODS";
const LS_MASTER_PRICE_CATEGORIES = "MASTER_PRICE_CATEGORIES";

/* util */
const toNumber = (v) =>
  v === "" || v == null ? 0 : Number(String(v).replace(/[^\d.-]/g, "")) || 0;
const fmt = (n) =>
  (Number(n) || 0).toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
  });
const nonEmpty = (v) =>
  v !== undefined && v !== null && String(v).trim() !== "";
const uniq = (arr) => Array.from(new Set(arr || []));

const defaultRefs = {
  paymentMethods: PAYMENT_METHODS,
  priceCategories: PRICE_CATEGORIES,
  mpProtectOptions: MP_PROTECT_OPTIONS,
  tenorOptions: TENOR_OPTIONS,
  brandList: BRAND_LIST,
  productList: PRODUCT_LIST,
  warnaList: WARNA_LIST,
};

function getLS(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}
function setLS(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* safe text rendering */
const safeText = (v) => {
  if (v == null) return "";
  if (typeof v === "object") {
    try {
      return JSON.stringify(v);
    } catch {
      return "[Object]";
    }
  }
  return String(v);
};

/* Parsing helpers reused from prior implementation */
const normHeaders = (row) =>
  Object.fromEntries(
    Object.entries(row || {}).map(([k, v]) => [
      String(k || "").toLowerCase().trim(),
      v,
    ])
  );
const slugSheet = (n) =>
  String(n || "").toLowerCase().replace(/\s+/g, "");

function parseSheetHarga(json) {
  const rows = (json || []).map(normHeaders);
  const out = [];
  for (const r of rows) {
    const brand = r["brand"] ?? r["merk"] ?? r["merek"];
    const name =
      r["type"] ?? r["tipe"] ?? r["produk"] ?? r["name"] ?? r["nama"];
    if (!nonEmpty(brand) || !nonEmpty(name)) continue;
    const warna = r["warna"] ?? r["color"];
    const srp = toNumber(r["srp"] ?? r["harga srp"]);
    const grosir = toNumber(r["grosir"] ?? r["harga grosir"]);
    const harga = toNumber(r["harga"]);
    const kategori = r["kategori"] ?? r["category"] ?? "";
    const baterai = r["baterai"] ?? r["battery"] ?? "";
    const charger = r["charger"] ?? r["pengisi daya"] ?? "";
    out.push({
      brand: String(brand).trim(),
      name: String(name).trim(),
      warna: warna ? String(warna).trim() : "",
      srp,
      grosir,
      harga: harga || grosir || srp || 0,
      kategori: kategori ? String(kategori).trim() : "",
      baterai: baterai ? String(baterai).trim() : "",
      charger: charger ? String(charger).trim() : "",
    });
  }
  return out;
}

function parseSheetSales(json) {
  const rows = (json || []).map(normHeaders);
  return rows
    .map((r) => {
      const toko = r["toko"] ?? r["nama toko"];
      const name = r["name"] ?? r["nama"] ?? r["sales"] ?? r["nama sales"];
      const nik = r["nik"] ?? r["id"];
      const sh = r["sh"] ?? r["nama sh"];
      const sl = r["sl"] ?? r["nama sl"];
      const tuyul = r["tuyul"] ?? r["freelance"] ?? r["teknisi"];
      if (!nonEmpty(name)) return null;
      return {
        toko: toko ? String(toko).trim() : "",
        name: String(name).trim(),
        nik: nik ? String(nik).trim() : "",
        sh: sh ? String(sh).trim() : "",
        sl: sl ? String(sl).trim() : "",
        tuyul: tuyul ? String(tuyul).trim() : "",
      };
    })
    .filter(Boolean);
}

function parseSheetMdr(json) {
  const rows = (json || []).map(normHeaders);
  return rows
    .map((r) => {
      const method = r["method"] ?? r["payment"] ?? r["pembayaran"];
      const toko = r["toko"] ?? r["nama toko"] ?? "";
      const brand = r["brand"] ?? r["merk"] ?? r["merek"] ?? "";
      const mdrPct = toNumber(r["mdr"] ?? r["mdr%"] ?? r["fee%"]);
      if (!nonEmpty(method)) return null;
      return {
        method: String(method).trim(),
        toko: String(toko).trim(),
        brand: String(brand).trim(),
        mdrPct,
      };
    })
    .filter(Boolean);
}

function parseSheetTenor(json) {
  const rows = (json || []).map(normHeaders);
  return rows
    .map((r) => {
      const tenor = toNumber(r["tenor"] ?? r["bulan"]);
      const bungaPct = toNumber(r["bunga"] ?? r["bunga%"] ?? r["interest"]);
      const method = r["method"] ?? r["payment"] ?? r["pembayaran"] ?? "";
      const brand = r["brand"] ?? r["merk"] ?? r["merek"] ?? "";
      const toko = r["toko"] ?? r["nama toko"] ?? "";
      if (!tenor) return null;
      return {
        tenor,
        bungaPct,
        method: String(method).trim(),
        brand: String(brand).trim(),
        toko: String(toko).trim(),
      };
    })
    .filter(Boolean);
}

function parseSheetToko(json) {
  const rows = (json || []).map(normHeaders);
  const out = {};
  for (const r of rows) {
    const id = r["id"] ?? r["kode"] ?? r["no"];
    const name = r["toko"] ?? r["nama toko"] ?? r["name"] ?? r["nama"];
    if (!nonEmpty(name)) continue;
    const key = nonEmpty(id)
      ? String(id).trim()
      : String(Object.keys(out).length + 1);
    out[key] = String(name).trim().toUpperCase();
  }
  return out;
}

function parseSimpleArray(json, keys) {
  const rows = (json || []).map(normHeaders);
  const arr = [];
  for (const r of rows) {
    for (const k of keys) {
      if (nonEmpty(r[k])) {
        arr.push(String(r[k]).trim());
        break;
      }
    }
  }
  return uniq(arr);
}

/* derive catalog from master */
function deriveCatalogFromMaster(masterHarga) {
  const map = new Map();
  for (const h of masterHarga || []) {
    const { brand, name, warna, baterai, charger } = h;
    if (!nonEmpty(brand) || !nonEmpty(name)) continue;
    if (!map.has(brand)) map.set(brand, new Map());
    const pm = map.get(brand);
    if (!pm.has(name))
      pm.set(name, {
        warna: new Set(),
        baterai: new Set(),
        charger: new Set(),
      });
    const rec = pm.get(name);
    if (nonEmpty(warna)) rec.warna.add(String(warna).trim());
    if (nonEmpty(baterai)) rec.baterai.add(String(baterai).trim());
    if (nonEmpty(charger)) rec.charger.add(String(charger).trim());
  }
  const out = [];
  for (const [brand, prodMap] of map.entries()) {
    const products = [];
    for (const [name, rec] of prodMap.entries()) {
      products.push({
        name,
        warna: Array.from(rec.warna),
        baterai: Array.from(rec.baterai),
        charger: Array.from(rec.charger),
      });
    }
    out.push({ brand, products });
  }
  return out;
}

/* ===== Component ===== */
export default function DataManagement() {
  /* ------- Master Harga ------- */
  const [master, setMaster] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_MASTER_PRICE) || "null");
      return Array.isArray(saved) && saved.length
        ? saved
        : (HARGA_PENJUALAN || []).map((x) => ({
            brand: x.brand,
            name: x.name,
            warna: x.warna || "",
            srp: toNumber(x.srp),
            grosir: toNumber(x.grosir),
            harga: toNumber(x.harga || x.grosir || x.srp || 0),
            kategori: x.kategori || "",
            baterai: x.baterai || "",
            charger: x.charger || "",
          }));
    } catch {
      return (HARGA_PENJUALAN || []).map((x) => ({
        brand: x.brand,
        name: x.name,
        warna: x.warna || "",
        srp: toNumber(x.srp),
        grosir: toNumber(x.grosir),
        harga: toNumber(x.harga || x.grosir || x.srp || 0),
        kategori: x.kategori || "",
        baterai: x.baterai || "",
        charger: x.charger || "",
      }));
    }
  });

  /* ------- Refs (lists) ------- */
  const [refs, setRefs] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_REF_LISTS) || "null");
      const base = saved || defaultRefs;
      return {
        paymentMethods: base.paymentMethods?.length ? base.paymentMethods : PAYMENT_METHODS,
        priceCategories: base.priceCategories?.length ? base.priceCategories : PRICE_CATEGORIES,
        mpProtectOptions: base.mpProtectOptions?.length ? base.mpProtectOptions : MP_PROTECT_OPTIONS,
        tenorOptions: base.tenorOptions?.length ? base.tenorOptions : TENOR_OPTIONS,
        brandList: base.brandList?.length ? base.brandList : BRAND_LIST,
        productList: base.productList?.length ? base.productList : PRODUCT_LIST,
        warnaList: base.warnaList?.length ? base.warnaList : WARNA_LIST,
      };
    } catch {
      return defaultRefs;
    }
  });

  /* ------- Organization & rules ------- */
  const [sales, setSales] = useState(() => getLS(LS_MASTER_SALES_BY_TOKO, []));
  const [mdrRules, setMdrRules] = useState(() => getLS(LS_MASTER_MDR_RULES, []));
  const [tenorRules, setTenorRules] = useState(() => getLS(LS_MASTER_TENOR_RULES, []));
  const [tokoLabels, setTokoLabels] = useState(() => getLS(LS_MASTER_TOKO_LABELS, TOKO_LABELS_DEFAULT || {}));

  /* ------- Penjualan dataset (master penjualan) ------- */
  // If using Firebase, initial penjualan will be loaded via listener.
  const [penjualan, setPenjualan] = useState(() => {
    if (USE_FIREBASE_PENJUALAN) return [];
    try {
      const s = JSON.parse(localStorage.getItem(STORAGE_PENJUALAN) || "null");
      return Array.isArray(s) ? s : [];
    } catch {
      return [];
    }
  });

  /* ------- Form master ------- */
  const [form, setForm] = useState({
    brand: "",
    name: "",
    warna: "",
    baterai: "",
    charger: "",
    srp: 0,
    grosir: 0,
    harga: 0,
    kategori: "",
    id: null,
  });

  /* master harga search/paging */
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  /* persist master harga + mirror */
  useEffect(() => {
    localStorage.setItem(STORAGE_MASTER_PRICE, JSON.stringify(master));
    setLS(LS_MASTER_HARGA_PENJUALAN, master);
    const catalog = deriveCatalogFromMaster(master);
    setLS(LS_MASTER_CATALOG_INDEX, catalog);
  }, [master]);

  useEffect(() => {
    localStorage.setItem(STORAGE_REF_LISTS, JSON.stringify(refs));
    setLS(LS_MASTER_MP_PROTECT_OPTIONS, refs.mpProtectOptions || []);
    setLS(LS_MASTER_PAYMENT_METHODS, refs.paymentMethods || []);
    setLS(LS_MASTER_PRICE_CATEGORIES, refs.priceCategories || []);
  }, [refs]);

  useEffect(() => setLS(LS_MASTER_SALES_BY_TOKO, sales), [sales]);
  useEffect(() => setLS(LS_MASTER_MDR_RULES, mdrRules), [mdrRules]);
  useEffect(() => setLS(LS_MASTER_TENOR_RULES, tenorRules), [tenorRules]);
  useEffect(() => setLS(LS_MASTER_TOKO_LABELS, tokoLabels), [tokoLabels]);

  useEffect(() => {
    if (!USE_FIREBASE_PENJUALAN) {
      localStorage.setItem(STORAGE_PENJUALAN, JSON.stringify(penjualan));
    }
  }, [penjualan]);

  /* If in firebase mode, attach realtime listener for penjualan */
  useEffect(() => {
    if (!USE_FIREBASE_PENJUALAN) return;

    let unsub = null;
    try {
      unsub = listenPenjualan((list) => {
        // normalize list structure if necessary
        setPenjualan(list || []);
      });
    } catch (err) {
      console.error("Failed to start penjualan listener:", err);
    }

    // optionally preload once (helpful on first load)
    (async () => {
      try {
        const once = await getAllPenjualanOnce();
        // if local currently empty, prefer server data
        if ((!penjualan || !penjualan.length) && once && once.length) {
          setPenjualan(once);
        }
      } catch (e) {
        // ignore
      }
    })();

    return () => {
      if (unsub) unsub();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [USE_FIREBASE_PENJUALAN]);

  /* derived master table */
  const filtered = useMemo(() => {
    const q = (search || "").toLowerCase();
    return master.filter(
      (r) =>
        (r.brand || "").toLowerCase().includes(q) ||
        (r.name || "").toLowerCase().includes(q) ||
        (r.warna || "").toLowerCase().includes(q) ||
        (r.kategori || "").toLowerCase().includes(q)
    );
  }, [master, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageRows = filtered.slice((page - 1) * pageSize, page * pageSize);

  /* ------- Master handlers ------- */
  const onChange = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const addRow = () => {
    const row = {
      brand: String(form.brand || "").trim(),
      name: String(form.name || "").trim(),
      warna: String(form.warna || "").trim(),
      baterai: form.baterai ? String(form.baterai).trim() : "",
      charger: form.charger ? String(form.charger).trim() : "",
      srp: toNumber(form.srp),
      grosir: toNumber(form.grosir),
      harga: toNumber(form.harga || form.grosir || form.srp),
      kategori: form.kategori ? String(form.kategori).trim() : "",
    };
    setMaster((prev) => [row, ...prev]);
    // enrich refs
    setRefs((r) => ({
      ...r,
      brandList: uniq([...(r.brandList || []), row.brand]),
      productList: uniq([...(r.productList || []), row.name]),
      warnaList: uniq([...(r.warnaList || []), row.warna]),
    }));
    setForm({ brand: "", name: "", warna: "", baterai: "", charger: "", srp: 0, grosir: 0, harga: 0, kategori: "", id: null });
  };

  const beginEditByIndex = (masterIdx) => {
    const r = master[masterIdx];
    if (!r) return;
    setForm({
      brand: String(r.brand || ""),
      name: String(r.name || ""),
      warna: r.warna || "",
      baterai: r.baterai || "",
      charger: r.charger || "",
      srp: r.srp,
      grosir: r.grosir,
      harga: r.harga || r.grosir || r.srp || 0,
      kategori: r.kategori,
      id: masterIdx,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const updateRow = () => {
    const idx = typeof form.id === "number" ? form.id : -1;
    if (idx < 0 || !master[idx]) {
      alert("Pilih baris yang akan diupdate (klik Edit di tabel).");
      return;
    }
    const row = {
      brand: String(form.brand || "").trim(),
      name: String(form.name || "").trim(),
      warna: String(form.warna || "").trim(),
      baterai: form.baterai ? String(form.baterai).trim() : "",
      charger: form.charger ? String(form.charger).trim() : "",
      srp: toNumber(form.srp),
      grosir: toNumber(form.grosir),
      harga: toNumber(form.harga || form.grosir || form.srp),
      kategori: form.kategori ? String(form.kategori).trim() : "",
    };
    setMaster((prev) => prev.map((x, i) => (i === idx ? row : x)));
    setForm({ brand: "", name: "", warna: "", baterai: "", charger: "", srp: 0, grosir: 0, harga: 0, kategori: "", id: null });
  };

  const deleteRowByIndex = (masterIdx) => {
    if (!window.confirm("Hapus baris ini?")) return;
    setMaster((prev) => prev.filter((_, i) => i !== masterIdx));
  };

  /* ------- Refs management ------- */
  const addRef = (key, value) => {
    if (!nonEmpty(value)) return;
    setRefs((r) => ({ ...r, [key]: uniq([...(r[key] || []), value]) }));
  };
  const deleteRef = (key, value) => {
    setRefs((r) => ({ ...r, [key]: (r[key] || []).filter((x) => x !== value) }));
  };

  /* ------- Sales / MDR / Tenor / Toko editor (ringkas) ------- */
  const [newSales, setNewSales] = useState({ toko: "", store: "", name: "", nik: "", sh: "", sl: "", tuyul: "" });
  const addSales = () => {
    if (!nonEmpty(newSales.name)) return;
    setSales((prev) => [newSales, ...prev]);
    setNewSales({ toko: "", store: "", name: "", nik: "", sh: "", sl: "", tuyul: "" });
  };
  const delSales = (idx) => setSales((prev) => prev.filter((_, i) => i !== idx));

  const [newMdr, setNewMdr] = useState({ method: "", toko: "", brand: "", mdrPct: 0 });
  const addMdr = () => {
    if (!nonEmpty(newMdr.method)) return;
    setMdrRules((prev) => [{ ...newMdr, mdrPct: toNumber(newMdr.mdrPct) }, ...prev]);
    setNewMdr({ method: "", toko: "", brand: "", mdrPct: 0 });
  };
  const delMdr = (idx) => setMdrRules((prev) => prev.filter((_, i) => i !== idx));

  const [newTenor, setNewTenor] = useState({ tenor: 0, bungaPct: 0, method: "", brand: "", toko: "" });
  const addTenor = () => {
    if (!toNumber(newTenor.tenor)) return;
    setTenorRules((prev) => [{ ...newTenor, tenor: toNumber(newTenor.tenor), bungaPct: toNumber(newTenor.bungaPct) }, ...prev]);
    setNewTenor({ tenor: 0, bungaPct: 0, method: "", brand: "", toko: "" });
  };
  const delTenor = (idx) => setTenorRules((prev) => prev.filter((_, i) => i !== idx));

  const [newToko, setNewToko] = useState({ id: "", name: "" });
  const addToko = () => {
    if (!nonEmpty(newToko.name)) return;
    setTokoLabels((prev) => {
      const next = { ...(prev || {}) };
      const id = newToko.id ? String(newToko.id) : String(Object.keys(next).length + 1);
      next[id] = String(newToko.name).toUpperCase();
      return next;
    });
    setNewToko({ id: "", name: "" });
  };
  const delToko = (id) => {
    setTokoLabels((prev) => {
      const next = { ...(prev || {}) };
      delete next[id];
      return next;
    });
  };

  /* ------- PENJUALAN (new dataset) ------- */
  // penjualan form state
  const [pjForm, setPjForm] = useState({
    id: null,
    TANGGAL: "",
    PAYMENT_METODE: "",
    MDR: "",
    KATEGORI: "",
    MP_PROTECK: "",
    TENOR: "",
    NAMA_SALES: "",
    NIK: "",
    TOKO: "",
    SH: "",
    SL: "",
    TUYUL: "",
    BRAND: "",
    WARNA: "",
    QTY: 1,
    BATERAI: "",
    SEPEDA_LISTRIK: "",
    CHARGER: "",
    STATUS: "Pending",
  });

  // helpers to gather dropdown sources from current state
  const derivedBrands = uniq([...(refs.brandList || []), ...(master.map((m) => m.brand) || [])]).filter(Boolean);
  const derivedWarna = uniq([...(refs.warnaList || []), ...(master.map((m) => m.warna) || [])]).filter(Boolean);
  const derivedBaterai = uniq([...(master.map((m) => m.baterai) || []), ...(penjualan.map((p) => p.BATERAI) || [])]).filter(Boolean);
  const derivedCharger = uniq([...(master.map((m) => m.charger) || []), ...(penjualan.map((p) => p.CHARGER) || [])]).filter(Boolean);
  const tokoNames = Object.values(tokoLabels || {}) || [];
  const paymentMethods = refs.paymentMethods || PAYMENT_METHODS;
  const mpProtectOptions = refs.mpProtectOptions || MP_PROTECT_OPTIONS;
  const tenorOptions = refs.tenorOptions?.length ? refs.tenorOptions : TENOR_OPTIONS;
  const salesNames = uniq([...(sales.map((s) => s.name) || []), ...(penjualan.map((p) => p.NAMA_SALES) || [])]).filter(Boolean);

  // add/edit penjualan
  const savePenjualan = async () => {
    // minimal validation (non-blocking)
    // create payload
    const payload = {
      ...pjForm,
      QTY: Number(pjForm.QTY) || 0,
      // ensure numeric HARGA if provided
      HARGA: pjForm.HARGA !== undefined ? Number(pjForm.HARGA) : undefined,
    };

    // If FIREBASE mode, write to Firebase and rely on listener to update local state
    if (USE_FIREBASE_PENJUALAN) {
      try {
        if (pjForm.id && String(pjForm.id).startsWith("pj_")) {
          // local id format - we still use firebase update if mapping exists
          // try update by id
          await updatePenjualan(pjForm.id, payload);
        } else if (pjForm.id) {
          // assume it's firebase key
          await updatePenjualan(pjForm.id, payload);
        } else {
          await addPenjualan(payload);
        }
        // reset form (listener will update penjualan state)
        setPjForm({
          id: null, TANGGAL: "", PAYMENT_METODE: "", MDR: "", KATEGORI: "", MP_PROTECK: "",
          TENOR: "", NAMA_SALES: "", NIK: "", TOKO: "", SH: "", SL: "", TUYUL: "",
          BRAND: "", WARNA: "", QTY: 1, BATERAI: "", SEPEDA_LISTRIK: "", CHARGER: "", STATUS: "Pending"
        });
      } catch (err) {
        console.error("Firebase penjualan save error:", err);
        alert("Gagal menyimpan penjualan ke Firebase: " + (err.message || err));
      }
      return;
    }

    // Local mode
    if (pjForm.id) {
      setPenjualan((prev) => prev.map((r) => (r.id === pjForm.id ? { ...r, ...payload } : r)));
    } else {
      const newRow = { ...payload, id: `pj_${Date.now()}` };
      setPenjualan((prev) => [newRow, ...(prev || [])]);
    }

    // enrich refs/toko/sales lists locally
    if (pjForm.BRAND) setRefs((r) => ({ ...r, brandList: uniq([...(r.brandList || []), pjForm.BRAND]) }));
    if (pjForm.WARNA) setRefs((r) => ({ ...r, warnaList: uniq([...(r.warnaList || []), pjForm.WARNA]) }));
    if (pjForm.NAMA_SALES) setSales((s) => uniq([...(s || []), { toko: pjForm.TOKO, name: pjForm.NAMA_SALES }]));

    setPjForm({
      id: null, TANGGAL: "", PAYMENT_METODE: "", MDR: "", KATEGORI: "", MP_PROTECK: "",
      TENOR: "", NAMA_SALES: "", NIK: "", TOKO: "", SH: "", SL: "", TUYUL: "",
      BRAND: "", WARNA: "", QTY: 1, BATERAI: "", SEPEDA_LISTRIK: "", CHARGER: "", STATUS: "Pending"
    });
  };

  const editPenjualan = (row) => {
    setPjForm({ ...row });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const deletePenjualanLocalOrRemote = async (id) => {
    if (!window.confirm("Hapus data penjualan ini?")) return;

    if (USE_FIREBASE_PENJUALAN) {
      try {
        await deletePenjualan(id);
        // listener will remove locally
      } catch (err) {
        console.error("Firebase delete error:", err);
        alert("Gagal menghapus di Firebase: " + (err.message || err));
      }
      return;
    }

    // local
    setPenjualan((prev) => prev.filter((r) => r.id !== id));
  };

  const approvePenjualanLocalOrRemote = async (id, status) => {
    if (USE_FIREBASE_PENJUALAN) {
      try {
        await updatePenjualan(id, { STATUS: status });
      } catch (err) {
        console.error("Firebase approve error:", err);
        alert("Gagal mengubah status di Firebase: " + (err.message || err));
      }
      return;
    }

    setPenjualan((prev) => prev.map((r) => (r.id === id ? { ...r, STATUS: status } : r)));
  };

  // filtering/paging for penjualan table
  const [pjFilterToko, setPjFilterToko] = useState("ALL");
  const [pjFilterStatus, setPjFilterStatus] = useState("ALL");
  const [pjSearch, setPjSearch] = useState("");
  const [pjPage, setPjPage] = useState(1);
  const pjPageSize = 10;
  const filteredPenjualan = useMemo(() => {
    const q = (pjSearch || "").toLowerCase();
    return (penjualan || []).filter((r) => {
      const tokoMatch = pjFilterToko === "ALL" ? true : String(r.TOKO) === String(pjFilterToko);
      const statusMatch = pjFilterStatus === "ALL" ? true : String(r.STATUS) === String(pjFilterStatus);
      const textMatch = !q
        ? true
        : (safeText(r.BRAND) + " " + safeText(r.WARNA) + " " + safeText(r.NAMA_SALES) + " " + safeText(r.TOKO)).toLowerCase().includes(q);
      return tokoMatch && statusMatch && textMatch;
    });
  }, [penjualan, pjFilterToko, pjFilterStatus, pjSearch]);

  const pjTotalPages = Math.max(1, Math.ceil((filteredPenjualan || []).length / pjPageSize));
  const pjPageRows = (filteredPenjualan || []).slice((pjPage - 1) * pjPageSize, pjPage * pjPageSize);

  /* ------- Import/Export (ke-extend: import Excel also updates penjualan if sheet present) ------- */
  const fileRef = useRef(null);

  const exportAllExcel = () => {
    const wb = XLSX.utils.book_new();
    // Master Harga sheet
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (master || []).map((r) => ({
          Brand: safeText(r.brand),
          Type: safeText(r.name),
          Warna: safeText(r.warna),
          SRP: r.srp,
          Grosir: r.grosir,
          Harga: r.harga,
          Kategori: safeText(r.kategori),
          Baterai: safeText(r.baterai || ""),
          Charger: safeText(r.charger || ""),
        }))
      ),
      "Harga"
    );

    // Penjualan sheet (if any)
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (penjualan || []).map((p) => ({
          TANGGAL: p.TANGGAL,
          PAYMENT_METODE: p.PAYMENT_METODE,
          MDR: p.MDR,
          KATEGORI: p.KATEGORI,
          MP_PROTECK: p.MP_PROTECK,
          TENOR: p.TENOR,
          NAMA_SALES: p.NAMA_SALES,
          NIK: p.NIK,
          TOKO: p.TOKO,
          SH: p.SH,
          SL: p.SL,
          TUYUL: p.TUYUL,
          BRAND: p.BRAND,
          WARNA: p.WARNA,
          QTY: p.QTY,
          BATERAI: p.BATERAI,
          SEPEDA_LISTRIK: p.SEPEDA_LISTRIK,
          CHARGER: p.CHARGER,
          STATUS: p.STATUS,
        }))
      ),
      "Penjualan"
    );

    // Sales
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (sales || []).map((s) => ({ Toko: safeText(s.toko), Nama: safeText(s.name), NIK: safeText(s.nik) }))
      ),
      "Sales"
    );

    // Toko
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(Object.entries(tokoLabels || {}).map(([id, name]) => ({ ID: id, Toko: safeText(name) }))),
      "Toko"
    );

    // refs simple lists
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet((refs.paymentMethods || []).map((x) => ({ Method: safeText(x) }))), "PaymentMethods");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet((refs.priceCategories || []).map((x) => ({ Kategori: safeText(x) }))), "PriceCategories");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet((refs.mpProtectOptions || []).map((x) => ({ Opsi: safeText(x) }))), "MPProtect");

    XLSX.writeFile(wb, "DataMilaPhone_Export_All.xlsx");
  };

  const exportPenjualanPDF = () => {
    const el = document.getElementById("penjualanTable");
    if (!el) {
      alert("Tabel penjualan tidak ditemukan.");
      return;
    }
    html2canvas(el, { scale: 1.2 }).then((canvas) => {
      const img = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4");
      const w = pdf.internal.pageSize.getWidth();
      const h = (canvas.height * w) / canvas.width;
      pdf.addImage(img, "PNG", 0, 0, w, h);
      pdf.save("Laporan_Penjualan.pdf");
    });
  };

  const importExcel = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(new Uint8Array(e.target.result), { type: "array" });
        const pick = (...names) => {
          const set = new Set(names.map(slugSheet));
          const hit = wb.SheetNames.find((n) => set.has(slugSheet(n)));
          return hit ? XLSX.utils.sheet_to_json(wb.Sheets[hit], { defval: "" }) : null;
        };

        const shHarga = pick("harga", "masterharga", "price");
        const shKatalog = pick("katalog", "catalog", "produk");
        const shSales = pick("sales", "tim", "saleslist");
        const shMdr = pick("mdr", "fee");
        const shTenor = pick("tenor", "bunga");
        const shToko = pick("toko", "store", "outlet");
        const shPay = pick("paymentmethods", "payment", "metode");
        const shPCat = pick("pricecategories", "pricecategory", "kategoriharga");
        const shMP = pick("mpprotect", "mp protect", "mp");
        const shPenjualan = pick("penjualan", "transaksi", "salesdata", "data");

        // Master harga
        let newMaster = master;
        if (shHarga && shHarga.length) newMaster = parseSheetHarga(shHarga);

        // Sales / MDR / Tenor / Toko / Lists
        const newSales = shSales ? parseSheetSales(shSales) : sales;
        const newMdr = shMdr ? parseSheetMdr(shMdr) : mdrRules;
        const newTenor = shTenor ? parseSheetTenor(shTenor) : tenorRules;
        const newToko = shToko ? parseSheetToko(shToko) : tokoLabels;

        const newPay = shPay && shPay.length ? parseSimpleArray(shPay, ["method", "metode", "payment"]) : refs.paymentMethods;
        const newPCat = shPCat && shPCat.length ? parseSimpleArray(shPCat, ["kategori", "category", "pricecategory"]) : refs.priceCategories;
        const newMP = shMP && shMP.length ? parseSimpleArray(shMP, ["opsi", "option", "nama", "name", "mpprotect", "mp"]) : refs.mpProtectOptions;

        // Penjualan sheet (optional)
        let newPenjualan = null;
        if (shPenjualan && shPenjualan.length) {
          newPenjualan = shPenjualan.map((r, idx) => {
            const norm = normHeaders(r);
            return {
              id: `imp_${Date.now()}_${idx}`,
              TANGGAL: norm["tanggal"] || norm["date"] || "",
              PAYMENT_METODE: norm["payment metode"] || norm["payment_metode"] || norm["paymentmethod"] || "",
              MDR: norm["mdr"] || "",
              KATEGORI: norm["kategori"] || norm["category"] || "",
              MP_PROTECK: norm["mp proteck"] || norm["mp_proteck"] || norm["mp"] || "",
              TENOR: norm["tenor"] || "",
              NAMA_SALES: norm["nama sales"] || norm["nama"] || norm["sales"] || "",
              NIK: norm["nik"] || "",
              TOKO: norm["toko"] || "",
              SH: norm["sh"] || "",
              SL: norm["sl"] || "",
              TUYUL: norm["tuyul"] || "",
              BRAND: norm["brand"] || "",
              WARNA: norm["warna"] || "",
              QTY: toNumber(norm["qty"]),
              BATERAI: norm["baterai"] || "",
              SEPEDA_LISTRIK: norm["sepeda listrik"] || norm["sepeda_listrik"] || "",
              CHARGER: norm["charger"] || "",
              STATUS: norm["status"] || "Pending",
            };
          });
        }

        // Commit
        setMaster(newMaster);
        setSales(newSales);
        setMdrRules(newMdr);
        setTenorRules(newTenor);
        setTokoLabels(newToko);
        setRefs((prev) => ({ ...prev, paymentMethods: newPay, priceCategories: newPCat, mpProtectOptions: newMP }));

        if (newPenjualan && newPenjualan.length) {
          if (USE_FIREBASE_PENJUALAN) {
            // push each imported penjualan to firebase
            newPenjualan.slice().reverse().forEach(async (row) => {
              try {
                // don't await to speed up, listener will sync
                await addPenjualan(row);
              } catch (err) {
                console.error("Failed to push imported penjualan to firebase", err);
              }
            });
          } else {
            // prepend imported penjualan locally
            setPenjualan((prev) => [...(newPenjualan || []), ...(prev || [])]);
          }
        }

        alert("Import berhasil. Dataset diperbarui.");
      } catch (err) {
        console.error(err);
        alert("Gagal mengimpor file. Pastikan format sheet sesuai template.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  /* reset defaults */
  const resetDefaults = () => {
    if (!window.confirm("Yakin reset seluruh Master Data ke default repository?")) return;
    [
      STORAGE_MASTER_PRICE, STORAGE_REF_LISTS, LS_MASTER_HARGA_PENJUALAN,
      LS_MASTER_CATALOG_INDEX, LS_MASTER_SALES_BY_TOKO, LS_MASTER_MDR_RULES,
      LS_MASTER_TENOR_RULES, LS_MASTER_TOKO_LABELS, LS_MASTER_MP_PROTECT_OPTIONS,
      LS_MASTER_PAYMENT_METHODS, LS_MASTER_PRICE_CATEGORIES, STORAGE_PENJUALAN
    ].forEach((k) => localStorage.removeItem(k));
    setMaster((HARGA_PENJUALAN || []).map((x) => ({
      brand: x.brand, name: x.name, warna: x.warna || "", srp: toNumber(x.srp),
      grosir: toNumber(x.grosir), harga: toNumber(x.harga || x.grosir || x.srp || 0),
      kategori: x.kategori || "", baterai: x.baterai || "", charger: x.charger || ""
    })));
    setRefs(defaultRefs);
    setSales([]);
    setMdrRules([]);
    setTenorRules([]);
    setTokoLabels(TOKO_LABELS_DEFAULT || {});
    setPenjualan([]);
    alert("Berhasil reset. Master Data kembali ke default.");
  };

  /* ------- Render ------- */
  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-xl md:text-2xl font-bold">Data Management (Master Data) Mila Phone Pusat</h2>
        <div className="flex items-center gap-2">
          <button onClick={exportAllExcel} className="px-3 py-2 bg-green-600 text-white rounded shadow-sm">Export All (.xlsx)</button>
          <label className="px-3 py-2 bg-gray-100 border rounded cursor-pointer shadow-sm">
            Import Excel
            <input type="file" accept=".xlsx,.xls" className="hidden" ref={fileRef} onChange={(e) => e.target.files?.[0] && importExcel(e.target.files[0])} />
          </label>
          <button onClick={resetDefaults} className="px-3 py-2 bg-rose-600 text-white rounded shadow-sm">Reset Default</button>
        </div>
      </div>

      {/* Master Harga form */}
      <div className="bg-white rounded-lg shadow p-4 grid md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm">Kategori</label>
          <input value={form.kategori} onChange={(e) => onChange("kategori", e.target.value)} className="w-full border rounded p-2" placeholder="cth: Motor Listrik / Handphone / Accessories" />
        </div>
        <div>
          <label className="block text-sm">Brand</label>
          <input list="dm-brand" value={form.brand} onChange={(e) => onChange("brand", e.target.value)} className="w-full border rounded p-2" />
          <datalist id="dm-brand">{(refs.brandList || []).map((b) => <option key={b} value={b} />)}</datalist>
        </div>
        <div>
          <label className="block text-sm">Nama Produk</label>
          <input list="dm-product" value={form.name} onChange={(e) => onChange("name", e.target.value)} className="w-full border rounded p-2" />
          <datalist id="dm-product">{(refs.productList || []).map((p) => <option key={p} value={p} />)}</datalist>
        </div>
        <div>
          <label className="block text-sm">Warna</label>
          <input list="dm-warna" value={form.warna} onChange={(e) => onChange("warna", e.target.value)} className="w-full border rounded p-2" />
          <datalist id="dm-warna">{(refs.warnaList || []).map((w) => <option key={w} value={w} />)}</datalist>
        </div>
        <div>
          <label className="block text-sm">Baterai</label>
          <input value={form.baterai} onChange={(e) => onChange("baterai", e.target.value)} className="w-full border rounded p-2" placeholder="cth: Lithium 60V" />
        </div>
        <div>
          <label className="block text-sm">Charger</label>
          <input value={form.charger} onChange={(e) => onChange("charger", e.target.value)} className="w-full border rounded p-2" placeholder="cth: 5A" />
        </div>

        <div>
          <label className="block text-sm">SRP</label>
          <input value={form.srp} onChange={(e) => onChange("srp", toNumber(e.target.value))} className="w-full border rounded p-2 text-right" />
        </div>
        <div>
          <label className="block text-sm">Grosir</label>
          <input value={form.grosir} onChange={(e) => onChange("grosir", toNumber(e.target.value))} className="w-full border rounded p-2 text-right" />
        </div>
        <div>
          <label className="block text-sm">Harga (final, opsional)</label>
          <input value={form.harga} onChange={(e) => onChange("harga", toNumber(e.target.value))} className="w-full border rounded p-2 text-right" placeholder="kosongkan = pakai Grosir/SRP" />
        </div>

        <div className="md:col-span-3 flex gap-2">
          <button onClick={addRow} className="px-4 py-2 bg-blue-600 text-white rounded">Tambah</button>
          <button onClick={updateRow} className="px-4 py-2 bg-amber-600 text-white rounded">Update Baris</button>
          <div className="ml-auto">
            <input placeholder="Cari brand/produk/warna…" className="border rounded p-2" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
          </div>
        </div>
      </div>

      {/* Master Harga table */}
      <div className="overflow-auto bg-white rounded-lg shadow">
        <table className="min-w-[1200px] w-full">
          <thead className="bg-gray-50">
            <tr className="text-left">
              <th className="p-2">Brand</th>
              <th className="p-2">Produk</th>
              <th className="p-2">Warna</th>
              <th className="p-2">Baterai</th>
              <th className="p-2">Charger</th>
              <th className="p-2">SRP</th>
              <th className="p-2">Grosir</th>
              <th className="p-2">Harga</th>
              <th className="p-2">Kategori</th>
              <th className="p-2">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r, i) => {
              const masterIdx = master.indexOf(r);
              return (
                <tr key={masterIdx} className="border-t">
                  <td className="p-2">{safeText(r.brand)}</td>
                  <td className="p-2">{safeText(r.name)}</td>
                  <td className="p-2">{safeText(r.warna)}</td>
                  <td className="p-2">{safeText(r.baterai || "-")}</td>
                  <td className="p-2">{safeText(r.charger || "-")}</td>
                  <td className="p-2">{fmt(r.srp)}</td>
                  <td className="p-2">{fmt(r.grosir)}</td>
                  <td className="p-2">{fmt(r.harga)}</td>
                  <td className="p-2">{safeText(r.kategori)}</td>
                  <td className="p-2">
                    <div className="flex gap-2">
                      <button onClick={() => beginEditByIndex(masterIdx)} className="px-2 py-1 text-xs bg-amber-500 text-white rounded">Edit</button>
                      <button onClick={() => deleteRowByIndex(masterIdx)} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Delete</button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={10} className="p-4 text-center text-gray-500">Tidak ada data.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div>Halaman {page} / {totalPages} (Total {filtered.length})</div>
        <div className="flex gap-2">
          <button disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} className={`px-3 py-1 border rounded ${page <= 1 ? "opacity-50" : ""}`}>Prev</button>
          <button disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} className={`px-3 py-1 border rounded ${page >= totalPages ? "opacity-50" : ""}`}>Next</button>
        </div>
      </div>

      {/* ======= Editors: simple lists ======= */}
      <div className="bg-white rounded-lg shadow p-4 grid md:grid-cols-3 gap-4">
        <RefEditor title="Payment Methods" listKey="paymentMethods" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="Price Categories" listKey="priceCategories" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="MP Protect Options" listKey="mpProtectOptions" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="Tenor Options" listKey="tenorOptions" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="Brand List" listKey="brandList" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="Product List" listKey="productList" refs={refs} onAdd={addRef} onDel={deleteRef} />
        <RefEditor title="Warna List" listKey="warnaList" refs={refs} onAdd={addRef} onDel={deleteRef} />
      </div>

      {/* ======= Editors: Sales / MDR / Tenor / Toko (same as before) ======= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Sales */}
        <section className="bg-white rounded-lg shadow p-4">
          <div className="font-semibold mb-2">Sales / Organisasi</div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-2">
            <input className="border rounded p-2" placeholder="Toko" value={newSales.toko} onChange={(e) => setNewSales((s) => ({ ...s, toko: e.target.value }))} />
            <input className="border rounded p-2" placeholder="Store" value={newSales.store} onChange={(e) => setNewSales((s) => ({ ...s, store: e.target.value }))} />
            <input className="border rounded p-2" placeholder="Nama" value={newSales.name} onChange={(e) => setNewSales((s) => ({ ...s, name: e.target.value }))} />
            <input className="border rounded p-2" placeholder="NIK" value={newSales.nik} onChange={(e) => setNewSales((s) => ({ ...s, nik: e.target.value }))} />
            <input className="border rounded p-2" placeholder="SH" value={newSales.sh} onChange={(e) => setNewSales((s) => ({ ...s, sh: e.target.value }))} />
            <input className="border rounded p-2" placeholder="SL" value={newSales.sl} onChange={(e) => setNewSales((s) => ({ ...s, sl: e.target.value }))} />
            <input className="border rounded p-2" placeholder="Tuyul/Freelance" value={newSales.tuyul} onChange={(e) => setNewSales((s) => ({ ...s, tuyul: e.target.value }))} />
          </div>
          <button onClick={addSales} className="px-3 py-2 bg-blue-600 text-white rounded">Tambah</button>
          <div className="overflow-auto mt-3 border rounded">
            <table className="min-w-[800px] w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="p-2 text-left">Toko</th>
                  <th className="p-2 text-left">Store</th>
                  <th className="p-2 text-left">Nama</th>
                  <th className="p-2 text-left">NIK</th>
                  <th className="p-2 text-left">SH</th>
                  <th className="p-2 text-left">SL</th>
                  <th className="p-2 text-left">Tuyul</th>
                  <th className="p-2 text-left">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {(sales || []).map((s, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-2">{safeText(s.toko)}</td>
                    <td className="p-2">{safeText(s.store)}</td>
                    <td className="p-2">{safeText(s.name)}</td>
                    <td className="p-2">{safeText(s.nik)}</td>
                    <td className="p-2">{safeText(s.sh)}</td>
                    <td className="p-2">{safeText(s.sl)}</td>
                    <td className="p-2">{safeText(s.tuyul)}</td>
                    <td className="p-2"><button onClick={() => delSales(i)} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Hapus</button></td>
                  </tr>
                ))}
                {!sales?.length && (
                  <tr>
                    <td colSpan={8} className="p-3 text-center text-gray-500">Kosong.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* MDR */}
        <section className="bg-white rounded-lg shadow p-4">
          <div className="font-semibold mb-2">Aturan MDR</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
            <input className="border rounded p-2" placeholder="Method (Cash/Transfer/...)" value={newMdr.method} onChange={(e) => setNewMdr((m) => ({ ...m, method: e.target.value }))} />
            <input className="border rounded p-2" placeholder="Toko (opsional)" value={newMdr.toko} onChange={(e) => setNewMdr((m) => ({ ...m, toko: e.target.value }))} />
            <input className="border rounded p-2" placeholder="Brand (opsional)" value={newMdr.brand} onChange={(e) => setNewMdr((m) => ({ ...m, brand: e.target.value }))} />
            <input className="border rounded p-2 text-right" placeholder="MDR %" value={newMdr.mdrPct} onChange={(e) => setNewMdr((m) => ({ ...m, mdrPct: toNumber(e.target.value) }))} />
          </div>
          <button onClick={addMdr} className="px-3 py-2 bg-blue-600 text-white rounded">Tambah</button>
          <div className="overflow-auto mt-3 border rounded">
            <table className="min-w-[700px] w-full text-sm">
              <thead className="bg-gray-50"><tr><th className="p-2">Method</th><th className="p-2">Toko</th><th className="p-2">Brand</th><th className="p-2 text-right">MDR%</th><th className="p-2">Aksi</th></tr></thead>
              <tbody>{(mdrRules || []).map((m, i) => (<tr key={i} className="border-t"><td className="p-2">{safeText(m.method)}</td><td className="p-2">{safeText(m.toko||"-")}</td><td className="p-2">{safeText(m.brand||"-")}</td><td className="p-2 text-right">{m.mdrPct}</td><td className="p-2"><button onClick={() => delMdr(i)} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Hapus</button></td></tr>))}{!mdrRules?.length && (<tr><td colSpan={5} className="p-3 text-center text-gray-500">Kosong.</td></tr>)}</tbody>
            </table>
          </div>
        </section>
      </div>

      {/* ======== PENJUALAN SECTION ======== */}
      <div className="bg-white rounded-lg shadow p-4">
        <h3 className="font-semibold mb-3">Penjualan (Tambah / Edit) — DataMilaPhone {USE_FIREBASE_PENJUALAN ? "(Realtime Firebase)" : "(Local)"}</h3>

        {/* form penjualan (UI unchanged) */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* fields ... (kept unchanged) */}
          <div>
            <label className="text-xs">Tanggal</label>
            <input type="date" className="w-full border p-2 rounded" value={pjForm.TANGGAL} onChange={(e) => setPjForm((p) => ({ ...p, TANGGAL: e.target.value }))} />
          </div>

          <div>
            <label className="text-xs">Payment Metode</label>
            <select className="w-full border p-2 rounded" value={pjForm.PAYMENT_METODE} onChange={(e) => setPjForm((p) => ({ ...p, PAYMENT_METODE: e.target.value }))}>
              <option value="">-- pilih --</option>
              {paymentMethods.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">MDR</label>
            <select className="w-full border p-2 rounded" value={pjForm.MDR} onChange={(e) => setPjForm((p) => ({ ...p, MDR: e.target.value }))}>
              <option value="">-- pilih --</option>
              {mdrRules.map((m, i) => <option key={i} value={`${m.method}${m.mdrPct ? ` (${m.mdrPct}%)` : ""}`}>{m.method} {m.mdrPct ? `- ${m.mdrPct}%` : ""}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Kategori</label>
            <select className="w-full border p-2 rounded" value={pjForm.KATEGORI} onChange={(e) => setPjForm((p) => ({ ...p, KATEGORI: e.target.value }))}>
              <option value="">-- pilih --</option>
              {(refs.priceCategories || []).map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">MP Protect</label>
            <select className="w-full border p-2 rounded" value={pjForm.MP_PROTECK} onChange={(e) => setPjForm((p) => ({ ...p, MP_PROTECK: e.target.value }))}>
              <option value="">-- pilih --</option>
              {(mpProtectOptions || []).map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Tenor</label>
            <select className="w-full border p-2 rounded" value={pjForm.TENOR} onChange={(e) => setPjForm((p) => ({ ...p, TENOR: e.target.value }))}>
              <option value="">-- pilih --</option>
              {(tenorOptions || []).map((t) => <option key={t.tenor || t} value={t.tenor || t}>{t.tenor || t}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Nama Sales</label>
            <select className="w-full border p-2 rounded" value={pjForm.NAMA_SALES} onChange={(e) => setPjForm((p) => ({ ...p, NAMA_SALES: e.target.value }))}>
              <option value="">-- pilih --</option>
              {salesNames.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">NIK</label>
            <input className="w-full border p-2 rounded" value={pjForm.NIK} onChange={(e) => setPjForm((p) => ({ ...p, NIK: e.target.value }))} />
          </div>

          <div>
            <label className="text-xs">Toko</label>
            <select className="w-full border p-2 rounded" value={pjForm.TOKO} onChange={(e) => setPjForm((p) => ({ ...p, TOKO: e.target.value }))}>
              <option value="">-- pilih --</option>
              {tokoNames.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">SH</label>
            <select className="w-full border p-2 rounded" value={pjForm.SH} onChange={(e) => setPjForm((p) => ({ ...p, SH: e.target.value }))}>
              <option value="">-- pilih --</option>
              {uniq(sales.map(s => s.sh)).filter(Boolean).map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">SL</label>
            <select className="w-full border p-2 rounded" value={pjForm.SL} onChange={(e) => setPjForm((p) => ({ ...p, SL: e.target.value }))}>
              <option value="">-- pilih --</option>
              {uniq(sales.map(s => s.sl)).filter(Boolean).map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Tuyul</label>
            <select className="w-full border p-2 rounded" value={pjForm.TUYUL} onChange={(e) => setPjForm((p) => ({ ...p, TUYUL: e.target.value }))}>
              <option value="">-- pilih --</option>
              {uniq(sales.map(s => s.tuyul)).filter(Boolean).map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Brand</label>
            <select className="w-full border p-2 rounded" value={pjForm.BRAND} onChange={(e) => setPjForm((p) => ({ ...p, BRAND: e.target.value }))}>
              <option value="">-- pilih --</option>
              {derivedBrands.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Warna</label>
            <select className="w-full border p-2 rounded" value={pjForm.WARNA} onChange={(e) => setPjForm((p) => ({ ...p, WARNA: e.target.value }))}>
              <option value="">-- pilih --</option>
              {derivedWarna.map((w) => <option key={w} value={w}>{w}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Qty</label>
            <input type="number" className="w-full border p-2 rounded text-right" value={pjForm.QTY} onChange={(e) => setPjForm((p) => ({ ...p, QTY: toNumber(e.target.value) }))} />
          </div>

          <div>
            <label className="text-xs">Baterai</label>
            <select className="w-full border p-2 rounded" value={pjForm.BATERAI} onChange={(e) => setPjForm((p) => ({ ...p, BATERAI: e.target.value }))}>
              <option value="">-- pilih --</option>
              {derivedBaterai.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs">Sepeda Listrik</label>
            <input className="w-full border p-2 rounded" value={pjForm.SEPEDA_LISTRIK} onChange={(e) => setPjForm((p) => ({ ...p, SEPEDA_LISTRIK: e.target.value }))} placeholder="nama model/tipe" />
          </div>

          <div>
            <label className="text-xs">Charger</label>
            <select className="w-full border p-2 rounded" value={pjForm.CHARGER} onChange={(e) => setPjForm((p) => ({ ...p, CHARGER: e.target.value }))}>
              <option value="">-- pilih --</option>
              {derivedCharger.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

        </div>

        <div className="mt-3 flex gap-2">
          <button onClick={savePenjualan} className="px-3 py-2 bg-blue-600 text-white rounded">{pjForm.id ? "Update Penjualan" : "Tambah Penjualan"}</button>
          <button onClick={() => { setPjForm({ id: null, TANGGAL: "", PAYMENT_METODE: "", MDR: "", KATEGORI: "", MP_PROTECK: "", TENOR: "", NAMA_SALES: "", NIK: "", TOKO: "", SH: "", SL: "", TUYUL: "", BRAND: "", WARNA: "", QTY: 1, BATERAI: "", SEPEDA_LISTRIK: "", CHARGER: "", STATUS: "Pending" }); }} className="px-3 py-2 bg-gray-200 rounded">Reset Form</button>
          <div className="ml-auto flex gap-2">
            <button onClick={exportPenjualanPDF} className="px-3 py-2 bg-red-600 text-white rounded">Export Penjualan PDF</button>
            <button onClick={() => {
              const wb = XLSX.utils.book_new();
              XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet((penjualan || []).map(p => ({ ...p }))), "Penjualan");
              XLSX.writeFile(wb, "Penjualan_Export.xlsx");
            }} className="px-3 py-2 bg-green-600 text-white rounded">Export Penjualan Excel</button>
          </div>
        </div>
      </div>

      {/* Penjualan Table */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-2 mb-3">
          <input placeholder="Cari penjualan..." className="border p-2 rounded" value={pjSearch} onChange={(e) => { setPjSearch(e.target.value); setPjPage(1); }} />
          <select className="border p-2 rounded" value={pjFilterToko} onChange={(e) => setPjFilterToko(e.target.value)}>
            <option value="ALL">Semua Toko</option>
            {tokoNames.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <select className="border p-2 rounded" value={pjFilterStatus} onChange={(e) => setPjFilterStatus(e.target.value)}>
            <option value="ALL">Semua Status</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        <div id="penjualanTable" className="overflow-auto">
          <table className="min-w-[1200px] w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-2">Tanggal</th>
                <th className="p-2">Toko</th>
                <th className="p-2">Sales</th>
                <th className="p-2">Brand</th>
                <th className="p-2">Warna</th>
                <th className="p-2">Qty</th>
                <th className="p-2">Baterai</th>
                <th className="p-2">Sepeda</th>
                <th className="p-2">Charger</th>
                <th className="p-2">Status</th>
                <th className="p-2">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {pjPageRows.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-2">{r.TANGGAL}</td>
                  <td className="p-2">{safeText(r.TOKO)}</td>
                  <td className="p-2">{safeText(r.NAMA_SALES)}</td>
                  <td className="p-2">{safeText(r.BRAND)}</td>
                  <td className="p-2">{safeText(r.WARNA)}</td>
                  <td className="p-2 text-center">{r.QTY}</td>
                  <td className="p-2">{safeText(r.BATERAI)}</td>
                  <td className="p-2">{safeText(r.SEPEDA_LISTRIK)}</td>
                  <td className="p-2">{safeText(r.CHARGER)}</td>
                  <td className={`p-2 font-semibold ${r.STATUS === "Approved" ? "text-green-600" : r.STATUS === "Rejected" ? "text-red-600" : "text-yellow-600"}`}>{r.STATUS}</td>
                  <td className="p-2">
                    <div className="flex gap-2">
                      <button onClick={() => editPenjualan(r)} className="px-2 py-1 text-xs bg-amber-500 text-white rounded">Edit</button>
                      <button onClick={() => deletePenjualanLocalOrRemote(r.id)} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Delete</button>
                      <button onClick={() => approvePenjualanLocalOrRemote(r.id, "Approved")} className="px-2 py-1 text-xs bg-green-600 text-white rounded">Approve</button>
                      <button onClick={() => approvePenjualanLocalOrRemote(r.id, "Rejected")} className="px-2 py-1 text-xs bg-orange-500 text-white rounded">Reject</button>
                    </div>
                  </td>
                </tr>
              ))}
              {(pjPageRows || []).length === 0 && (<tr><td colSpan={11} className="p-4 text-center text-gray-500">Tidak ada data penjualan.</td></tr>)}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center mt-3 text-sm">
          <span>Halaman {pjPage} dari {pjTotalPages} ({filteredPenjualan.length} data)</span>
          <div className="space-x-2">
            <button onClick={() => setPjPage((p) => Math.max(1, p - 1))} disabled={pjPage === 1} className="px-2 py-1 border rounded">Prev</button>
            <button onClick={() => setPjPage((p) => Math.min(pjTotalPages, p + 1))} disabled={pjPage === pjTotalPages} className="px-2 py-1 border rounded">Next</button>
          </div>
        </div>
      </div>

      <p className="text-xs text-gray-500">Semua perubahan otomatis disimpan ke localStorage. Untuk sinkronisasi online gunakan FirebaseService (Mode {FIREBASE_MODE}) — Mode 3 aktif: hanya penjualan realtime.</p>
    </div>
  );
}

/* small component: RefEditor */
function RefEditor({ title, listKey, refs, onAdd, onDel }) {
  const [val, setVal] = useState("");
  const list = refs[listKey] || [];
  return (
    <div>
      <div className="font-semibold mb-2">{title}</div>
      <div className="flex gap-2">
        <input value={val} onChange={(e) => setVal(e.target.value)} className="border rounded p-2 w-full" placeholder={`Tambah ${title}…`} />
        <button onClick={() => { onAdd(listKey, val); setVal(""); }} className="px-3 py-2 bg-blue-600 text-white rounded">Add</button>
      </div>
      <div className="mt-2 max-h-40 overflow-auto border rounded p-2">
        {list.map((x) => (
          <div key={x} className="flex justify-between items-center py-1">
            <span className="text-sm">{safeText(x)}</span>
            <button onClick={() => onDel(listKey, x)} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Hapus</button>
          </div>
        ))}
        {list.length === 0 && <div className="text-xs text-gray-500">Kosong.</div>}
      </div>
    </div>
  );
}
